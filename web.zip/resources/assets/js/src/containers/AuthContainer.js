import React from 'react';

const AuthContainer = ({ children }) => {
  return (
    <div className="formContainer">
        {children}
    </div>
  );
}

export default AuthContainer;