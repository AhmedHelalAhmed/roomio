import React from 'react';

const AuthContainer = ({ children }) => (
  <div className="formContainer">
    {children}
  </div>
  );

export default AuthContainer;
